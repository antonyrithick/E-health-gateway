import React from 'react';

const DoctorVideo = () => {
  // Implement video conferencing UI for doctor here
  return <div>Doctor's Video</div>;
};

export default DoctorVideo;

// Similarly, implement PatientVideo.js
