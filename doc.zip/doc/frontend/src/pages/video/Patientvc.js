import React from 'react';

const DoctorVideo = () => {
  // Implement video conferencing UI for doctor here
  return (
    <div className="video-container">
      Doctor's Video
    </div>
  );
};

export default DoctorVideo;
